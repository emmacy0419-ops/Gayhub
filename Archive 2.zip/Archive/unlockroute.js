// PATH FOR LATER: app/api/unlock/[token]/route.js
import { NextResponse } from 'next/server';
import { supabase } from '@/lib/supabase';
import { decrypt } from '@/lib/crypto';

export async function GET(req, { params }) {
  try {
    const token = params.token;

    if (!token) {
      return NextResponse.json({ error: 'Missing token' }, { status: 400 });
    }

    // 1. Find the request with this token, and ensure it is confirmed
    const { data, error } = await supabase
      .from('unlock_requests')
      .select(`
        status,
        profiles ( display_name, contact_method, contact_value_encrypted )
      `)
      .eq('access_token', token)
      .single();

    if (error || !data) {
      return NextResponse.json({ error: 'Invalid link' }, { status: 404 });
    }

    if (data.status !== 'confirmed') {
      return NextResponse.json({ error: 'Payment not confirmed yet' }, { status: 403 });
    }

    // 2. Decrypt the contact info
    const decryptedContact = decrypt(data.profiles.contact_value_encrypted);

    // 3. Return the unlocked data
    return NextResponse.json({
      display_name: data.profiles.display_name,
      contact_method: data.profiles.contact_method,
      contact_value: decryptedContact,
    });

  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}