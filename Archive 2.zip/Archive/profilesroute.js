// PATH FOR LATER: app/api/admin/profiles/route.js
import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { supabase } from '@/lib/supabase';
import { encrypt } from '@/lib/crypto';

export async function POST(req) {
  try {
    // 1. Check if admin is logged in
    const cookieStore = cookies();
    const isAdmin = cookieStore.get('admin_auth')?.value === 'true';
    if (!isAdmin) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();

    // 2. Validate required consent fields
    if (!body.consent_date || !body.consent_reference) {
      return NextResponse.json({ error: 'Consent date and reference are required.' }, { status: 400 });
    }

    // 3. Encrypt the contact info before saving
    const encryptedContact = encrypt(body.contact_value);

    // 4. Save the Profile to Supabase
    const { data: profileData, error: profileError } = await supabase
      .from('profiles')
      .insert([
        {
          display_name: body.display_name,
          age: parseInt(body.age),
          occupation: body.occupation,
          relationship_status: body.relationship_status,
          country: body.country,
          city: body.city,
          bio: body.bio,
          reason_for_joining: body.reason_for_joining,
          contact_method: body.contact_method,
          contact_value_encrypted: encryptedContact,
        }
      ])
      .select()
      .single();

    if (profileError) throw profileError;

    // 5. Save the Consent Record linked to the profile
    const { error: consentError } = await supabase
      .from('consent_records')
      .insert([
        {
          profile_id: profileData.id,
          consent_method: body.consent_method,
          consent_date: body.consent_date,
          consent_reference: body.consent_reference,
          consent_scope: 'Listed on site; contact released to paying members',
        }
      ]);

    if (consentError) throw consentError;

    return NextResponse.json({ success: true, profile: profileData });

  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: error.message || 'Failed to add profile' }, { status: 500 });
  }
}