import { NextResponse } from 'next/server';

export async function POST(req) {
  try {
    const { password } = await req.json();

    // Check if the password matches the one in your .env.local file
    if (password === process.env.ADMIN_PASSWORD) {
      // In a real app we'd use secure cookies/sessions. 
      // For now, we set a simple cookie so the browser remembers you.
      const response = NextResponse.json({ success: true });
      response.cookies.set('admin_auth', 'true', {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        maxAge: 60 * 60 * 24, // 1 day
        path: '/',
      });
      return response;
    }

    return NextResponse.json({ error: 'Invalid password' }, { status: 401 });
  } catch (error) {
    return NextResponse.json({ error: 'Bad request' }, { status: 400 });
  }
}